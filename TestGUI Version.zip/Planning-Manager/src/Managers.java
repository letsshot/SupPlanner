import java.sql.*; 
import java.util.*; 

import javax.swing.JFrame;//���
import javax.swing.JPanel;//���
import javax.swing.JButton;//��ť
import javax.swing.JLabel;//��ǩ
import javax.swing.JTextField;//�ı���

import java.awt.Font;//����
import java.awt.Color;//��ɫ

import javax.swing.JPasswordField;//�����

import java.awt.event.ActionListener;//�¼�����
import java.awt.event.ActionEvent;//�¼�����

import javax.swing.JOptionPane;//��Ϣ����
public class Managers extends JFrame{
	 static Connection conn;  
	    static Statement st; 
	    public JPanel pnluser;
		 public JLabel lbluserLogIn;
		 public JLabel lbluserName;
		 public JLabel lbluserPWD;
		 public JLabel lbluserPWDag;
		 public JLabel role;
		 public JTextField txtName;
		 public JPasswordField pwdPwd;
		 public JPasswordField pwdPwdag;
		 public JTextField txtrole;
		 public JButton btnSub;
		 public JButton btnReset;
		 
		 
		 public JLabel register;
		 public JLabel login;
		 public JButton btnregister;
		 public JButton btnlogin;

		 public void UserChoose(){
			  pnluser = new JPanel();
			  register = new JLabel();
			  login=new JLabel();
			  btnregister = new JButton();
			  btnlogin = new JButton();
			  choose();
			 }
		 

			
			 
			 public void choose(){
			  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���ùرտ�ܵ�ͬʱ��������
			  this.setSize(300,300);//���ÿ�ܴ�СΪ��300,��200
			  this.setResizable(false);//���ÿ�ܲ����Ըı��С
			  this.setTitle("Choose");//���ÿ�ܱ���
			  this.pnluser.setLayout(null);//������岼�ֹ���
			  this.pnluser.setBackground(Color.cyan);//������屳����ɫ
			  this.register.setText("If you want to register,click here:");
			  this.register.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,14));
			  this.login.setText("If you want to login in,click here");
			  this.login.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,14));
			  
			  
			  this.btnregister.setText("register");
			  this.btnregister.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,10));
			  this.btnlogin.setText("Login in");
			  this.btnlogin.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,10));
			  this.register.setBounds(40,55,300,20);
			  this.login.setBounds(40,145,300,25);
			  this.btnregister.setBounds(85,100,120,40);
			  this.btnlogin.setBounds(85,200,120,40);
			  this.btnregister.addActionListener(new ActionListener()//������ʵ��ActionListener�ӿ�
			   {
			    public void actionPerformed(ActionEvent e){
	
			             dispose();
			            // UserRegister();
			           AnotherFrame an=  new AnotherFrame();
			             an.UserRegister();
			     	    
			    }    
			   }
			  ); 
			 // this.btnReset.setBounds(155,200,60,20);
			  this.btnlogin.addActionListener(new ActionListener()//������ʵ��ActionListener�ӿ�
			   {
			    public void actionPerformed(ActionEvent e){
			    	dispose();
			    	AnotherFrame an=  new AnotherFrame();
		             an.UserLogIn();
			    }    
			   }
			  );   
			  this.pnluser.add(register);
			  this.pnluser.add(login);
			  this.pnluser.add(btnregister);
			  this.pnluser.add(btnlogin);
			  this.add(pnluser);//������嵽���
			  this.setVisible(true);//���ÿ�ܿ���  
			 }
			/* public void btnsub_ActionEvent0(ActionEvent e){
				
				  public void 
				  
				 }*/
		 
		 
		 
		
			 
			
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		/*int choose=0;
		choose = scan.nextInt();*/
		Managers test=new Managers();
	    test.UserChoose();
		  /*  if(choose==1)
		    {
			 test.UserRegister();
		    }
		    if(choose==2)
		    {
			 test.UserLogIn();
		    }*/

	}
	public class AnotherFrame extends JFrame {
		public JPanel pnluser;
		 public JLabel lbluserLogIn;
		 public JLabel lbluserName;
		 public JLabel lbluserPWD;
		 public JLabel lbluserPWDag;
		 public JLabel role;
		 public JTextField txtName;
		 public JPasswordField pwdPwd;
		 public JPasswordField pwdPwdag;
		 public JTextField txtrole;
		 public JButton btnSub;
		 public JButton btnReset;
		 
		 
		 public JLabel register;
		 public JLabel login;
		 public JButton btnregister;
		 public JButton btnlogin;
		 public void UserRegister(){
			  pnluser = new JPanel();
			//  ID=new JLable();
			  lbluserLogIn = new JLabel();
			  lbluserName = new JLabel();
			  lbluserPWD = new JLabel();
			  lbluserPWDag = new JLabel();
			  role=new JLabel();
			  txtName = new JTextField();
			  pwdPwd = new JPasswordField();
			  pwdPwdag = new JPasswordField();
			  txtrole=new JTextField();
			  btnSub = new JButton();
			  btnReset = new JButton();
			  user();
			 }
		 

			
			 
			 public void user(){
			  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���ùرտ�ܵ�ͬʱ��������
			  this.setSize(300,300);//���ÿ�ܴ�СΪ��300,��200
			  this.setResizable(false);//���ÿ�ܲ����Ըı��С
			  this.setTitle("User register");//���ÿ�ܱ���
			  this.pnluser.setLayout(null);//������岼�ֹ���
			 // this.pnluser.setBackground(Color.cyan);//������屳����ɫ
			  this.lbluserLogIn.setText("register");//���ñ�ǩ����
			  this.lbluserLogIn.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,14));//���ñ�ǩ����
			  this.lbluserLogIn.setForeground(Color.RED);//���ñ�ǩ������ɫ
			  this.lbluserName.setText("email:");
			  this.lbluserName.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
			  this.lbluserPWD.setText("Password:");
			  this.lbluserPWD.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
			  this.lbluserPWDag.setText("Password again:");
			  this.lbluserPWDag.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
			  this.role.setText("role:");
			  this.role.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
			  
			  
			  this.btnSub.setText("register");
			  this.btnSub.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
			  this.btnReset.setText("Reset");
			  this.btnReset.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
			  this.lbluserLogIn.setBounds(120,15,60,20);//���ñ�ǩx����120,y����15,��60,��20
			  this.lbluserName.setBounds(40,55,60,20);
			  this.lbluserPWD.setBounds(40,85,60,25);
			  this.lbluserPWDag.setBounds(40,115,60,25);
			  this.role.setBounds(40,145,60,25);
			  this.txtName.setBounds(110,55,120,20);
			  this.pwdPwd.setBounds(110,85,120,20);
			  this.pwdPwdag.setBounds(110,115,120,20);
			  this.txtrole.setBounds(110,145,120,20);
			  this.btnSub.setBounds(85,200,60,20);
			  this.btnSub.addActionListener(new ActionListener()//������ʵ��ActionListener�ӿ�
			   {
			    public void actionPerformed(ActionEvent e){
			     btnsub_ActionEvent1(e);
			    }    
			   }
			  ); 
			  this.btnReset.setBounds(155,200,60,20);
			  this.btnReset.addActionListener(new ActionListener()//������ʵ��ActionListener�ӿ�
			   {
			    public void actionPerformed(ActionEvent e){
			     btnreset_ActionEvent1(e);
			    }    
			   }
			  );   
			  this.pnluser.add(lbluserLogIn);//���ر�ǩ�����
			  this.pnluser.add(lbluserName);
			  this.pnluser.add(lbluserPWD);
			  this.pnluser.add(lbluserPWDag);
			  this.pnluser.add(role);
			  this.pnluser.add(txtName);
			  this.pnluser.add(pwdPwd);
			  this.pnluser.add(pwdPwdag);
			  this.pnluser.add(txtrole);
			  this.pnluser.add(btnSub);
			  this.pnluser.add(btnReset);
			  this.add(pnluser);//������嵽���
			  this.setVisible(true);//���ÿ�ܿ���  
			 }
			 
			 public void btnsub_ActionEvent1(ActionEvent e){
			  String name = txtName.getText();
			  String pwd = String.valueOf(pwdPwd.getPassword());
			  String pwdag = String.valueOf(pwdPwdag.getPassword());
			  String role = txtrole.getText();
			  
			  if(name.equals("")){
			   JOptionPane.showMessageDialog(null,"email can't be empty","error",JOptionPane.ERROR_MESSAGE);
			   return;
			  }else if (pwd.equals("")){
			   JOptionPane.showMessageDialog(null,"password can't be empty","error",JOptionPane.ERROR_MESSAGE);
			   return;
			  }else if(pwdag.equals("")){
				  JOptionPane.showMessageDialog(null,"password should be input t","error",JOptionPane.ERROR_MESSAGE);
				  return;
			  }else if(role.equals("")){
				  JOptionPane.showMessageDialog(null,"role can't be empty","error",JOptionPane.ERROR_MESSAGE);
				  return;
			  }else if(!pwd.equals(pwdag)){
				  JOptionPane.showMessageDialog(null,"password is different!","error",JOptionPane.ERROR_MESSAGE);
				  return;
			  }else if(true){
			   this.dispose();
			  }
			  try {
					Connection connect = DriverManager.getConnection( "jdbc:mysql://127.0.0.1:3306/nihao","root","");
					System.out.println("Success connect Mysql server!");
					Statement stmt = connect.createStatement();
					 //st = (Statement) conn.createStatement();    // ��������ִ�о�̬sql����Statement����  
				      Statement stmt1 = connect.createStatement();
				      String sql = "INSERT INTO register(email,password,role)"  
			                   + " VALUES ('"+name+"','"+pwd+"','"+role+"')";  // �������ݵ�sql���  
				       
			           stmt1.executeUpdate(sql);  // ִ�в��������sql��䣬�����ز������ݵĸ���  
			           
					/*ResultSet rs = stmt1.executeQuery("select * from register");
					while (rs.next()) {
					    System.out.println(rs.getString("email"));
					  }*/
					}catch(SQLException e1)
					{
					}
			 }
			 
			 public void btnreset_ActionEvent1(ActionEvent e){
			  txtName.setText("");
			  pwdPwd.setText("");
			  pwdPwdag.setText("");
			  role.setText("");
			 }
			
			 
			 //loginin
			 
			 public void UserLogIn(){
				  pnluser = new JPanel();
				  lbluserLogIn = new JLabel();
				  lbluserName = new JLabel();
				  lbluserPWD = new JLabel();
				  txtName = new JTextField();
				  pwdPwd = new JPasswordField();
				  btnSub = new JButton();
				  btnReset = new JButton();
				  userInit();
				 }
				 
				 public void userInit(){
				  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���ùرտ�ܵ�ͬʱ��������
				  this.setSize(300,300);//���ÿ�ܴ�СΪ��300,��200
				  this.setResizable(false);//���ÿ�ܲ����Ըı��С
				  this.setTitle("User Login in");//���ÿ�ܱ���
				  this.pnluser.setLayout(null);//������岼�ֹ���
				 // this.pnluser.setBackground(Color.cyan);//������屳����ɫ
				  this.lbluserLogIn.setText("Login in");//���ñ�ǩ����
				  this.lbluserLogIn.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,14));//���ñ�ǩ����
				  this.lbluserLogIn.setForeground(Color.RED);//���ñ�ǩ������ɫ
				  this.lbluserName.setText("email:");
				  this.lbluserName.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,11));
				  this.lbluserPWD.setText("Password:");
				  this.lbluserPWD.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,11));
				  this.btnSub.setText("Login in");
				  this.btnSub.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
				  this.btnReset.setText("Reset");
				  this.btnReset.setFont(new Font("Dialog",Font.BOLD | Font.ITALIC,7));
				  this.lbluserLogIn.setBounds(120,15,60,20);//���ñ�ǩx����120,y����15,��60,��20
				  this.lbluserName.setBounds(50,55,60,20);
				  this.lbluserPWD.setBounds(50,85,60,25);
				  this.txtName.setBounds(110,55,120,20);
				  this.pwdPwd.setBounds(110,85,120,20);
				  this.btnSub.setBounds(85,120,60,20);
				  this.btnSub.addActionListener(new ActionListener()//������ʵ��ActionListener�ӿ�
				   {
				    public void actionPerformed(ActionEvent e){
				     btnsub_ActionEvent(e);
				    }    
				   }
				  ); 
				  this.btnReset.setBounds(155,120,60,20);
				  this.btnReset.addActionListener(new ActionListener()//������ʵ��ActionListener�ӿ�
				   {
				    public void actionPerformed(ActionEvent e){
				     btnreset_ActionEvent(e);
				    }    
				   }
				  );   
				  this.pnluser.add(lbluserLogIn);//���ر�ǩ�����
				  this.pnluser.add(lbluserName);
				  this.pnluser.add(lbluserPWD);
				  this.pnluser.add(txtName);
				  this.pnluser.add(pwdPwd);
				  this.pnluser.add(btnSub);
				  this.pnluser.add(btnReset);
				  this.add(pnluser);//������嵽���
				  this.setVisible(true);//���ÿ�ܿ���  
				 }
				 
				 public void btnsub_ActionEvent(ActionEvent e){
				  String name = txtName.getText();
				  String pwd = String.valueOf(pwdPwd.getPassword());
				  boolean login1 = false;
				  try {
				  Connection connect = DriverManager.getConnection( "jdbc:mysql://127.0.0.1:3306/nihao","root","");
					System.out.println("Success connect Mysql server!");
					Statement stmt = connect.createStatement();
					 //st = (Statement) conn.createStatement();    // ��������ִ�о�̬sql����Statement����  
				      Statement stmt1 = connect.createStatement();
					ResultSet rs = stmt1.executeQuery("select * from register where email='"+name+"'");
					// email='167312@supinfo.com'
					while (rs.next()) {
						//String em=rs.getString("email");
						 String pa=rs.getString("password");
						// System.out.println(em);
						// System.out.println(pa);
						
					    if(pa.equals(pwd))
					    {
					        login1= true; 
					        break;
					    }
						
						// String pa=rs.getString("password");
						//System.out.println(pa);
						//login1=true;
					  }
					

					

					}catch(SQLException e1)
					{
					}
				  
				  if(name.equals("")){
				   JOptionPane.showMessageDialog(null,"email can't be empty","error",JOptionPane.ERROR_MESSAGE);
				   return;
				  }else if (pwd.equals("")){
				   JOptionPane.showMessageDialog(null,"password can't be empty","error",JOptionPane.ERROR_MESSAGE);
				   return;
				  }else if(login1){
				   this.dispose();
				  }else{
				   JOptionPane.showMessageDialog(null,"your email or password is error","error",JOptionPane.ERROR_MESSAGE);
				   return;
				  }
				 }
				 
				 public void btnreset_ActionEvent(ActionEvent e){
				  txtName.setText("");
				  pwdPwd.setText("");
				 }
			 
	}
	
}
